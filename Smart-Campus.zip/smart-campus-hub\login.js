// login.js
// Smart Campus Hub - Login logic (no backend)
// - Validation with inline error messages
// - Show/hide password
// - Dark/light mode compatible (uses same localStorage key as main app)
// - Stores the logged-in user in localStorage and redirects to dashboard (index.html)

(() => {
  const KEYS = {
    THEME: "sch_theme_v1",
    AUTH_USER: "sch_auth_user_v1",
    REMEMBER_EMAIL: "sch_remember_email_v1",
  };

  const $ = (sel, parent = document) => parent.querySelector(sel);

  function setError(inputEl, message) {
    const small = document.querySelector(`[data-error-for="${inputEl.id}"]`);
    if (small) small.textContent = message || "";
    inputEl.classList.toggle("is-invalid", Boolean(message));
  }

  function isValidEmail(email) {
    // Simple email pattern (good enough for client-side validation demo)
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function applyTheme(theme) {
    document.body.dataset.theme = theme;
    const icon = $("#themeIcon");
    if (icon) icon.textContent = theme === "light" ? "☀️" : "🌙";
  }

  function initTheme() {
    const saved = localStorage.getItem(KEYS.THEME) || "";
    const prefersLight =
      window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches;
    const theme = saved || (prefersLight ? "light" : "dark");
    applyTheme(theme);

    $("#themeToggle")?.addEventListener("click", () => {
      const current = document.body.dataset.theme === "light" ? "light" : "dark";
      const next = current === "light" ? "dark" : "light";
      localStorage.setItem(KEYS.THEME, next);
      applyTheme(next);
    });
  }

  function redirectToDashboard() {
    window.location.replace("./index.html");
  }

  function initAuthGuard() {
    // If already logged in, skip login page
    const raw = localStorage.getItem(KEYS.AUTH_USER);
    if (!raw) return;
    try {
      const user = JSON.parse(raw);
      if (user && user.email) redirectToDashboard();
    } catch {
      // ignore
    }
  }

  function initPasswordToggle() {
    const pass = $("#password");
    const btn = $("#togglePassword");
    if (!pass || !btn) return;

    btn.addEventListener("click", () => {
      const isHidden = pass.type === "password";
      pass.type = isHidden ? "text" : "password";
      btn.textContent = isHidden ? "Hide" : "Show";
      btn.setAttribute("aria-label", isHidden ? "Hide password" : "Show password");
    });
  }

  function initRememberMe() {
    const remembered = localStorage.getItem(KEYS.REMEMBER_EMAIL);
    if (remembered) {
      $("#email").value = remembered;
      $("#remember").checked = true;
    }
  }

  function showNotice(message) {
    const el = $("#loginNotice");
    if (!el) return;
    el.textContent = message;
    el.hidden = false;
  }

  function hideNotice() {
    const el = $("#loginNotice");
    if (!el) return;
    el.hidden = true;
    el.textContent = "";
  }

  function initForm() {
    const form = $("#loginForm");
    const emailEl = $("#email");
    const passEl = $("#password");
    const rememberEl = $("#remember");
    const btn = $("#loginBtn");

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      hideNotice();

      const email = emailEl.value.trim();
      const password = passEl.value;

      let ok = true;

      if (!email) {
        setError(emailEl, "Email is required.");
        ok = false;
      } else if (!isValidEmail(email)) {
        setError(emailEl, "Enter a valid email address.");
        ok = false;
      } else {
        setError(emailEl, "");
      }

      if (!password) {
        setError(passEl, "Password is required.");
        ok = false;
      } else if (password.length < 6) {
        setError(passEl, "Password must be at least 6 characters.");
        ok = false;
      } else {
        setError(passEl, "");
      }

      if (!ok) return;

      // In a no-backend project, "authentication" is a local demo:
      // store the logged user in localStorage.
      const user = {
        email,
        loginAt: new Date().toISOString(),
        remember: Boolean(rememberEl.checked),
      };

      localStorage.setItem(KEYS.AUTH_USER, JSON.stringify(user));

      // Remember email convenience
      if (rememberEl.checked) localStorage.setItem(KEYS.REMEMBER_EMAIL, email);
      else localStorage.removeItem(KEYS.REMEMBER_EMAIL);

      btn.disabled = true;
      btn.textContent = "Signing in…";
      showNotice("Login successful. Redirecting to dashboard…");

      // Small delay for nicer UX + to show animation/feedback
      window.setTimeout(() => {
        redirectToDashboard();
      }, 650);
    });
  }

  // Start
  initTheme();
  initAuthGuard();
  initPasswordToggle();
  initRememberMe();
  initForm();
})();

