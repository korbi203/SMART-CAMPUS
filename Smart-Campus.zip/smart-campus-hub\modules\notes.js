// notes.js
// Personal notes system:
// - Add/edit/delete notes
// - Auto saved using localStorage
// - Validation + dynamic rendering

import { KEYS, loadJSON, saveJSON } from "./storage.js";
import { $, create, toast, requireText, confirmAction } from "./ui.js";

const state = {
  notes: [],
  editingId: null,
  onChange: () => {},
};

function uuid() {
  return (crypto.randomUUID && crypto.randomUUID()) || `n_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

function loadNotes() {
  const list = loadJSON(KEYS.NOTES, []);
  state.notes = Array.isArray(list) ? list : [];
}

function persist() {
  saveJSON(KEYS.NOTES, state.notes);
}

function resetForm() {
  state.editingId = null;
  $("#noteTitle").value = "";
  $("#noteContent").value = "";
  $("#noteSubmit").textContent = "Save Note";
  $("#noteCancelEdit").hidden = true;
}

function fillFormForEdit(note) {
  state.editingId = note.id;
  $("#noteTitle").value = note.title;
  $("#noteContent").value = note.content;
  $("#noteSubmit").textContent = "Update Note";
  $("#noteCancelEdit").hidden = false;
}

function formatTime(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "Unknown time";
  return d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

function renderNotes() {
  const list = $("#noteList");
  if (!list) return;
  list.innerHTML = "";

  if (state.notes.length === 0) {
    list.appendChild(create("div", "muted", "No notes yet. Add your first note on the left."));
    return;
  }

  // Most recent first
  const notes = state.notes.slice().sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1));

  notes.forEach((note) => {
    const item = create("div", "item");
    item.dataset.id = note.id;

    const top = create("div", "item__top");
    const left = create("div", "");
    left.appendChild(create("div", "item__title", note.title));
    left.appendChild(create("div", "muted", note.content));
    left.appendChild(create("div", "item__meta", `Updated: ${formatTime(note.updatedAt)}`));

    const actions = create("div", "actions");
    const edit = create("button", "chip-btn", "Edit");
    edit.type = "button";
    edit.dataset.action = "edit";
    const del = create("button", "chip-btn chip-btn--danger", "Delete");
    del.type = "button";
    del.dataset.action = "delete";
    actions.appendChild(edit);
    actions.appendChild(del);

    top.appendChild(left);
    top.appendChild(actions);
    item.appendChild(top);
    list.appendChild(item);
  });
}

// Public (dashboard)
export function getNotesCount() {
  return state.notes.length;
}

function bindForm() {
  const form = $("#noteForm");
  const titleEl = $("#noteTitle");
  const contentEl = $("#noteContent");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const title = requireText(titleEl, "Title");
    const content = requireText(contentEl, "Content");
    if (!title || !content) return;

    const now = new Date().toISOString();

    if (!state.editingId) {
      const note = { id: uuid(), title, content, createdAt: now, updatedAt: now };
      state.notes.unshift(note);
      persist();
      toast("Note saved", "Stored in localStorage.");
    } else {
      const idx = state.notes.findIndex((n) => n.id === state.editingId);
      if (idx === -1) {
        resetForm();
        return;
      }
      state.notes[idx] = { ...state.notes[idx], title, content, updatedAt: now };
      persist();
      toast("Note updated", "Changes saved.");
    }

    resetForm();
    renderNotes();
    state.onChange();
  });

  $("#noteCancelEdit").addEventListener("click", () => resetForm());
}

function bindListActions() {
  const list = $("#noteList");
  list.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-action]");
    if (!btn) return;
    const item = e.target.closest(".item");
    if (!item) return;

    const id = item.dataset.id;
    const note = state.notes.find((n) => n.id === id);
    if (!note) return;

    if (btn.dataset.action === "edit") {
      fillFormForEdit(note);
      toast("Edit mode", "Update the note then click “Update Note”.", { ttlMs: 5000 });
      return;
    }

    if (btn.dataset.action === "delete") {
      if (!confirmAction("Delete this note permanently?")) return;
      state.notes = state.notes.filter((n) => n.id !== id);
      persist();
      renderNotes();
      state.onChange();
      toast("Note deleted", "Removed from localStorage.");
    }
  });
}

export function initNotes({ onChange }) {
  state.onChange = onChange || (() => {});
  loadNotes();
  bindForm();
  bindListActions();
  renderNotes();
}

