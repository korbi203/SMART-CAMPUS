// ui.js
// UI/UX module:
// - navigation (show/hide views)
// - theme toggle (saved in localStorage)
// - clock/date widget
// - motivational quotes (Fetch API)
// - toast notifications + notification drawer
// - dashboard update helpers
// - reusable validation utilities

import { KEYS, getText, setText, loadSessionJSON, saveSessionJSON } from "./storage.js";

const state = {
  getStats: null,
  notifications: [], // {id, title, message, timeISO}
};

// ---------- DOM helpers ----------
export function $(selector, parent = document) {
  return parent.querySelector(selector);
}

export function $$ (selector, parent = document) {
  return Array.from(parent.querySelectorAll(selector));
}

export function create(tag, className, text) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
}

function formatDateTime(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "Unknown time";
  return d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

function clamp(num, min, max) {
  return Math.min(max, Math.max(min, num));
}

// ---------- Theme ----------
function applyTheme(theme) {
  document.body.dataset.theme = theme;
  const icon = $("#themeIcon");
  if (icon) icon.textContent = theme === "light" ? "☀️" : "🌙";
}

function initTheme() {
  const saved = getText(KEYS.THEME, "");
  const prefersLight =
    window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches;
  const theme = saved || (prefersLight ? "light" : "dark");
  applyTheme(theme);

  $("#themeToggle")?.addEventListener("click", () => {
    const current = document.body.dataset.theme === "light" ? "light" : "dark";
    const next = current === "light" ? "dark" : "light";
    setText(KEYS.THEME, next);
    applyTheme(next);
    toast("Theme updated", `Switched to ${next} mode.`);
  });
}

// ---------- Navigation ----------
function setActiveNav(view) {
  $$("#nav .nav__item").forEach((btn) => {
    btn.classList.toggle("is-active", btn.dataset.view === view);
  });
}

function setActiveView(view) {
  $$(".view").forEach((v) => {
    v.classList.toggle("is-active", v.dataset.view === view);
  });
  const titleMap = {
    dashboard: "Dashboard",
    tasks: "Smart Task Manager",
    weather: "Weather",
    notes: "Notes",
    focus: "Pomodoro",
  };
  $("#pageTitle").textContent = titleMap[view] || "Smart Campus Hub";
}

export function navigateTo(view) {
  setActiveNav(view);
  setActiveView(view);
  saveSessionJSON(KEYS.SESSION_LAST_VIEW, view);
}

function initNavigation() {
  // Restore last view per tab (sessionStorage)
  const lastView = loadSessionJSON(KEYS.SESSION_LAST_VIEW, "dashboard");
  navigateTo(lastView);

  $("#nav")?.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-view]");
    if (!btn) return;
    navigateTo(btn.dataset.view);

    // On mobile, close sidebar after navigating
    $("#sidebar")?.classList.remove("is-open");
  });

  // Mobile sidebar toggle
  $("#sidebarToggle")?.addEventListener("click", () => {
    $("#sidebar")?.classList.toggle("is-open");
  });

  // Close sidebar by clicking outside (mobile)
  document.addEventListener("click", (e) => {
    const sidebar = $("#sidebar");
    if (!sidebar) return;
    const toggle = $("#sidebarToggle");
    const clickedInside = sidebar.contains(e.target) || toggle?.contains(e.target);
    if (!clickedInside) sidebar.classList.remove("is-open");
  });
}

// ---------- Clock ----------
function initClock() {
  const timeEl = $("#clockTime");
  const dateEl = $("#clockDate");
  if (!timeEl || !dateEl) return;

  const tick = () => {
    const now = new Date();
    timeEl.textContent = now.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
    dateEl.textContent = now.toLocaleDateString(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric",
    });
  };

  tick();
  setInterval(tick, 1000);
}

// ---------- Toasts ----------
export function toast(title, message, opts = {}) {
  const container = $("#toasts");
  if (!container) return;

  const el = create("div", "toast");
  el.setAttribute("role", "status");

  const top = create("div", "toast__top");
  const t = create("div", "toast__title", title);
  const close = create("button", "chip-btn", "✕");
  close.type = "button";
  close.setAttribute("aria-label", "Close");

  top.appendChild(t);
  top.appendChild(close);

  const text = create("div", "toast__text", message);
  el.appendChild(top);
  el.appendChild(text);

  close.addEventListener("click", () => el.remove());
  container.appendChild(el);

  const ttl = clamp(opts.ttlMs ?? 6000, 1500, 15000);
  window.setTimeout(() => {
    el.remove();
  }, ttl);
}

// ---------- Notification drawer ----------
function renderNotifications() {
  const list = $("#notifyList");
  const badge = $("#notifyBadge");
  if (!list || !badge) return;

  list.innerHTML = "";
  const notifs = state.notifications.slice().sort((a, b) => (a.timeISO < b.timeISO ? 1 : -1));

  if (notifs.length === 0) {
    const empty = create("div", "muted", "No notifications right now.");
    list.appendChild(empty);
  } else {
    notifs.forEach((n) => {
      const card = create("div", "notice");
      const h = create("div", "notice__title", n.title);
      const p = create("div", "notice__text", n.message);
      const time = create("div", "notice__time", formatDateTime(n.timeISO));
      card.appendChild(h);
      card.appendChild(p);
      card.appendChild(time);
      list.appendChild(card);
    });
  }

  badge.hidden = notifs.length === 0;
  badge.textContent = String(notifs.length);
}

export function pushNotification({ id, title, message, timeISO }) {
  // prevent duplicates
  if (state.notifications.some((n) => n.id === id)) return;
  state.notifications.push({ id, title, message, timeISO });
  renderNotifications();
}

export function clearNotifications() {
  state.notifications = [];
  renderNotifications();
}

function initNotificationDrawer() {
  const btn = $("#notifyBtn");
  const drawer = $("#notifyDrawer");
  const close = $("#notifyClose");

  const open = () => {
    if (!drawer) return;
    drawer.hidden = false;
    renderNotifications();
  };
  const hide = () => {
    if (!drawer) return;
    drawer.hidden = true;
  };

  btn?.addEventListener("click", () => {
    if (!drawer) return;
    drawer.hidden ? open() : hide();
  });
  close?.addEventListener("click", hide);

  // Close on Escape
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") hide();
  });
}

// ---------- Quotes (Fetch API) ----------
async function fetchQuote() {
  // quotable is a public API that works without an API key
  const res = await fetch("https://api.quotable.io/random", { cache: "no-store" });
  if (!res.ok) throw new Error("Quote API request failed");
  const data = await res.json();
  return { content: data.content, author: data.author };
}

async function renderQuote() {
  const textEl = $("#quoteText");
  const authorEl = $("#quoteAuthor");
  if (!textEl || !authorEl) return;

  textEl.textContent = "Loading quote…";
  authorEl.textContent = "";

  try {
    const q = await fetchQuote();
    textEl.textContent = `“${q.content}”`;
    authorEl.textContent = `— ${q.author}`;
  } catch (err) {
    textEl.textContent = "Could not load a quote (check your internet connection).";
    authorEl.textContent = "";
  }
}

function initQuotes() {
  $("#newQuoteBtn")?.addEventListener("click", () => {
    renderQuote();
  });
  renderQuote();
}

// ---------- Dashboard update ----------
export function updateDashboard() {
  if (!state.getStats) return;
  const { taskStats, notesCount, lastWeather } = state.getStats();

  // Cards
  $("#dashTotalTasks").textContent = String(taskStats.total);
  $("#dashCompletedTasks").textContent = String(taskStats.completed);
  $("#dashDueSoon").textContent = String(taskStats.dueSoon);
  $("#dashNotesCount").textContent = String(notesCount);

  const pct = taskStats.total === 0 ? 0 : Math.round((taskStats.completed / taskStats.total) * 100);
  $("#dashCompletion").textContent = `${pct}%`;
  $("#ringPercent").textContent = `${pct}%`;

  const ring = $("#completionRing");
  if (ring) {
    const deg = Math.round((pct / 100) * 360);
    ring.style.background = `conic-gradient(var(--ring-fill) ${deg}deg, var(--ring-bg) ${deg}deg)`;
  }

  // Quick weather summary
  const dashWeather = $("#dashWeather");
  if (dashWeather) {
    dashWeather.innerHTML = "";
    if (!lastWeather) {
      dashWeather.appendChild(create("div", "muted", "Search a city in the Weather section to see a quick summary here."));
    } else {
      const row = create("div", "weather__row");
      const left = create("div", "");
      const city = create("div", "weather__city", lastWeather.city);
      const meta = create(
        "div",
        "weather__meta",
        `${lastWeather.tempC}°C • ${lastWeather.description} • humidity ${lastWeather.humidity}%`
      );
      left.appendChild(city);
      left.appendChild(meta);

      const right = create("div", "");
      right.innerHTML = `<img class="weather__icon" alt="Weather icon" src="${lastWeather.iconUrl}" />`;
      row.appendChild(left);
      row.appendChild(right);
      dashWeather.appendChild(row);
    }
  }
}

// ---------- Validation utilities ----------
// Simple, reusable validation used by tasks/weather/notes forms.
export function setFieldError(inputEl, message) {
  const small = document.querySelector(`[data-error-for="${inputEl.id}"]`);
  if (small) small.textContent = message || "";
  inputEl.classList.toggle("is-invalid", Boolean(message));
}

export function requireText(inputEl, label) {
  const value = inputEl.value.trim();
  if (!value) {
    setFieldError(inputEl, `${label} is required.`);
    return null;
  }
  setFieldError(inputEl, "");
  return value;
}

export function clearFormErrors(formEl) {
  $$("[data-error-for]", formEl).forEach((el) => (el.textContent = ""));
}

export function confirmAction(message) {
  // For a university project: window.confirm is acceptable and explainable.
  return window.confirm(message);
}

// ---------- Init ----------
export function initUI({ getStats }) {
  state.getStats = getStats;

  initTheme();
  initNavigation();
  initClock();
  initQuotes();
  initNotificationDrawer();
  renderNotifications();
}

