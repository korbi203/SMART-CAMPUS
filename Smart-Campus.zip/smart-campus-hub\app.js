// Smart Campus Hub - App entry point (ES6 module)
// This file wires modules together and starts the application.

import { KEYS, loadJSON, remove } from "./modules/storage.js";
import { initUI, updateDashboard } from "./modules/ui.js";
import { initTasks, getTaskStats, checkDeadlineNotifications } from "./modules/tasks.js";
import { initNotes, getNotesCount } from "./modules/notes.js";
import { initWeather, getLastWeatherSummary } from "./modules/weather.js";

// --------- Simple localStorage authentication guard ----------
// If the user is not logged in, we redirect to login.html.
// This prevents opening index.html directly without authentication.
const authUser = loadJSON(KEYS.AUTH_USER, null);
if (!authUser) {
  window.location.replace("./login.html");
} else {
  // Show email in the top bar
  const emailEl = document.querySelector("#userEmail");
  if (emailEl) emailEl.textContent = authUser.email || "Student";

  // Logout button clears auth and redirects back to login page
  const logoutBtn = document.querySelector("#logoutBtn");
  logoutBtn?.addEventListener("click", () => {
    remove(KEYS.AUTH_USER);
    // Optional: clear session-only reminders
    sessionStorage.clear();
    window.location.replace("./login.html");
  });
}

// Boot order:
// 1) UI (theme, nav, clock, toasts)
// 2) Feature modules (tasks, notes, weather)
// 3) Dashboard refresh + deadline notification checks

// Only start the app if user is authenticated (avoid unnecessary initialization before redirect).
if (authUser) {
  initUI({
    // Dashboard stats come from multiple modules, so we provide small callbacks.
    getStats: () => {
      const taskStats = getTaskStats();
      const notesCount = getNotesCount();
      const lastWeather = getLastWeatherSummary();
      return { taskStats, notesCount, lastWeather };
    },
  });

  initTasks({
    onChange: () => {
      updateDashboard();
      checkDeadlineNotifications();
    },
  });

  initNotes({
    onChange: () => {
      updateDashboard();
    },
  });

  initWeather({
    onChange: () => {
      updateDashboard();
    },
  });

  // Initial render
  updateDashboard();
  checkDeadlineNotifications();

  // Periodic deadline checks (notification system)
  // This demonstrates timers + dynamic UI updates.
  setInterval(() => {
    checkDeadlineNotifications();
  }, 60_000); // every minute
}
