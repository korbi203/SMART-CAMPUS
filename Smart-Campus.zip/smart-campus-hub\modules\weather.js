// weather.js
// Weather section using OpenWeatherMap API (Fetch + async/await)
// - Search by city
// - Displays temperature, humidity, wind speed, icon
// - Stores last searched city + last result in localStorage
//
// IMPORTANT:
// Replace OPEN_WEATHER_API_KEY with your own key from:
// https://openweathermap.org/api

import { KEYS, getText, setText, loadJSON, saveJSON } from "./storage.js";
import { $, create, toast, requireText } from "./ui.js";

// Put your key here:
const OPEN_WEATHER_API_KEY = ""; // <-- add your key

const state = {
  lastSummary: null,
  onChange: () => {},
};

function hasKey() {
  return Boolean(OPEN_WEATHER_API_KEY && OPEN_WEATHER_API_KEY.trim().length > 10);
}

function toCelsius(kelvin) {
  return Math.round(kelvin - 273.15);
}

function iconUrl(iconCode) {
  // Use official icon CDN
  return `https://openweathermap.org/img/wn/${iconCode}@2x.png`;
}

async function fetchWeatherByCity(city) {
  if (!hasKey()) {
    // Demonstrate async error handling
    throw new Error("Missing OpenWeatherMap API key");
  }

  const url = new URL("https://api.openweathermap.org/data/2.5/weather");
  url.searchParams.set("q", city);
  url.searchParams.set("appid", OPEN_WEATHER_API_KEY);

  const res = await fetch(url.toString(), { cache: "no-store" });
  if (!res.ok) {
    // Try to read error message for nicer UX
    let msg = "Weather request failed.";
    try {
      const data = await res.json();
      msg = data.message ? `Weather: ${data.message}` : msg;
    } catch {
      // ignore
    }
    throw new Error(msg);
  }

  const data = await res.json();
  return data;
}

function renderWeather(data, cityFallback) {
  const result = $("#weatherResult");
  if (!result) return;
  result.innerHTML = "";

  const city = `${data.name || cityFallback}${data.sys?.country ? ", " + data.sys.country : ""}`;
  const tempC = toCelsius(data.main?.temp ?? 0);
  const humidity = data.main?.humidity ?? 0;
  const wind = data.wind?.speed ?? 0;
  const description = (data.weather?.[0]?.description || "Unknown").replace(/^\w/, (c) => c.toUpperCase());
  const icon = data.weather?.[0]?.icon || "01d";

  const row = create("div", "weather__row");
  const left = create("div", "");
  left.appendChild(create("div", "weather__city", city));
  left.appendChild(create("div", "weather__meta", description));

  const right = create("div", "");
  const temp = create("div", "weather__temp", `${tempC}°C`);
  right.appendChild(temp);

  row.appendChild(left);
  row.appendChild(right);

  const meta = create("div", "weather__row");
  meta.appendChild(create("div", "tag", `Humidity: ${humidity}%`));
  meta.appendChild(create("div", "tag", `Wind: ${wind} m/s`));

  const iconBox = create("div", "weather__row");
  iconBox.innerHTML = `<div class="tag">Icon</div><img class="weather__icon" alt="Weather icon" src="${iconUrl(
    icon
  )}" />`;

  result.appendChild(row);
  result.appendChild(meta);
  result.appendChild(iconBox);

  // Save quick summary for dashboard card
  state.lastSummary = {
    city,
    tempC,
    humidity,
    description,
    iconUrl: iconUrl(icon),
    timeISO: new Date().toISOString(),
  };

  saveJSON(KEYS.LAST_WEATHER, state.lastSummary);
  state.onChange();
}

function renderKeyMissingMessage() {
  const result = $("#weatherResult");
  if (!result) return;
  result.innerHTML = "";
  result.appendChild(
    create(
      "div",
      "muted",
      "OpenWeatherMap API key is missing. Add your key in modules/weather.js (OPEN_WEATHER_API_KEY) to enable live weather."
    )
  );
}

function renderLoading() {
  const result = $("#weatherResult");
  if (!result) return;
  result.innerHTML = "";
  result.appendChild(create("div", "muted", "Loading weather…"));
}

function bindForm() {
  const form = $("#weatherForm");
  const cityEl = $("#weatherCity");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const city = requireText(cityEl, "City");
    if (!city) return;

    setText(KEYS.LAST_CITY, city);
    renderLoading();

    try {
      const data = await fetchWeatherByCity(city);
      renderWeather(data, city);
      toast("Weather updated", `Fetched live weather for ${city}.`);
    } catch (err) {
      if (!hasKey()) {
        renderKeyMissingMessage();
        toast("API key required", "Add your OpenWeatherMap API key to enable this feature.", { ttlMs: 10000 });
      } else {
        $("#weatherResult").innerHTML = "";
        $("#weatherResult").appendChild(create("div", "muted", String(err.message || err)));
        toast("Weather error", "Could not fetch weather. Try another city.", { ttlMs: 8000 });
      }
    }
  });
}

function restoreLastCity() {
  const last = getText(KEYS.LAST_CITY, "");
  if (last) $("#weatherCity").value = last;
}

export function getLastWeatherSummary() {
  if (state.lastSummary) return state.lastSummary;
  const saved = loadJSON(KEYS.LAST_WEATHER, null);
  state.lastSummary = saved;
  return saved;
}

export function initWeather({ onChange }) {
  state.onChange = onChange || (() => {});
  restoreLastCity();
  getLastWeatherSummary();
  bindForm();
}

