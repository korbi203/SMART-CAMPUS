// tasks.js
// Smart Task Manager:
// - CRUD tasks with priority + deadline
// - Filters, search, sorting
// - Progress tracking
// - Deadline notification system
// - Data validation
// - Persisted using localStorage (storage.js)

import { KEYS, loadJSON, saveJSON, loadSessionJSON, saveSessionJSON } from "./storage.js";
import { $, create, toast, requireText, setFieldError, confirmAction, pushNotification } from "./ui.js";

const PRIORITY_WEIGHT = { low: 1, medium: 2, high: 3 };

const state = {
  tasks: [],
  editingId: null,
  onChange: () => {},
};

function uuid() {
  // crypto.randomUUID is supported in modern browsers; fallback for older ones
  return (crypto.randomUUID && crypto.randomUUID()) || `t_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

function loadTasks() {
  const list = loadJSON(KEYS.TASKS, []);
  // Ensure basic shape (defensive)
  state.tasks = Array.isArray(list) ? list : [];
}

function persist() {
  saveJSON(KEYS.TASKS, state.tasks);
}

function parseDeadline(inputValue) {
  if (!inputValue) return null;
  const d = new Date(inputValue);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}

function humanPriority(p) {
  return p === "high" ? "High" : p === "medium" ? "Medium" : "Low";
}

function getDeadlineStatus(deadlineISO) {
  if (!deadlineISO) return { label: "No deadline", isOverdue: false, dueMs: null };
  const now = Date.now();
  const due = new Date(deadlineISO).getTime();
  const diff = due - now;
  const isOverdue = diff < 0;
  return { label: isOverdue ? "Overdue" : "Due", isOverdue, dueMs: diff };
}

function withinHours(deadlineISO, hours) {
  if (!deadlineISO) return false;
  const diff = new Date(deadlineISO).getTime() - Date.now();
  return diff > 0 && diff <= hours * 60 * 60 * 1000;
}

function validateTaskForm({ titleEl, deadlineEl }) {
  const title = requireText(titleEl, "Title");
  if (!title) return null;

  // Deadline is optional, but if provided it must be valid
  const deadlineISO = parseDeadline(deadlineEl.value);
  if (deadlineEl.value && !deadlineISO) {
    setFieldError(deadlineEl, "Please provide a valid date/time.");
    return null;
  }
  setFieldError(deadlineEl, "");

  return { title, deadlineISO };
}

function upsertTask(task) {
  const idx = state.tasks.findIndex((t) => t.id === task.id);
  if (idx === -1) state.tasks.unshift(task);
  else state.tasks[idx] = task;
  persist();
  state.onChange();
}

function resetForm() {
  state.editingId = null;
  $("#taskTitle").value = "";
  $("#taskDesc").value = "";
  $("#taskPriority").value = "medium";
  $("#taskDeadline").value = "";
  $("#taskSubmit").textContent = "Add Task";
  $("#taskCancelEdit").hidden = true;
}

function fillFormForEdit(task) {
  state.editingId = task.id;
  $("#taskTitle").value = task.title;
  $("#taskDesc").value = task.description || "";
  $("#taskPriority").value = task.priority || "medium";
  $("#taskDeadline").value = task.deadline ? task.deadline.slice(0, 16) : ""; // ISO -> datetime-local
  $("#taskSubmit").textContent = "Update Task";
  $("#taskCancelEdit").hidden = false;
}

function renderProgress() {
  const total = state.tasks.length;
  const completed = state.tasks.filter((t) => t.completed).length;
  const pct = total === 0 ? 0 : Math.round((completed / total) * 100);
  $("#taskProgressText").textContent = `${completed}/${total} completed`;
  $("#taskProgressPercent").textContent = `${pct}%`;
  $("#taskProgressFill").style.width = `${pct}%`;
}

function matchesSearch(task, query) {
  if (!query) return true;
  const q = query.toLowerCase();
  return (
    task.title.toLowerCase().includes(q) ||
    (task.description || "").toLowerCase().includes(q) ||
    humanPriority(task.priority).toLowerCase().includes(q)
  );
}

function applyFilterAndSort(tasks, filter, sort, searchQuery) {
  let list = tasks.slice();

  // Filter
  if (filter === "active") list = list.filter((t) => !t.completed);
  if (filter === "completed") list = list.filter((t) => t.completed);
  if (filter === "dueSoon") list = list.filter((t) => !t.completed && withinHours(t.deadline, 24));

  // Search
  list = list.filter((t) => matchesSearch(t, searchQuery));

  // Sort
  if (sort === "deadlineAsc") {
    list.sort((a, b) => {
      const ad = a.deadline ? new Date(a.deadline).getTime() : Number.POSITIVE_INFINITY;
      const bd = b.deadline ? new Date(b.deadline).getTime() : Number.POSITIVE_INFINITY;
      return ad - bd;
    });
  }
  if (sort === "priorityDesc") {
    list.sort((a, b) => (PRIORITY_WEIGHT[b.priority] || 0) - (PRIORITY_WEIGHT[a.priority] || 0));
  }
  if (sort === "createdDesc") {
    list.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
  }

  return list;
}

function renderTaskList() {
  const listEl = $("#taskList");
  if (!listEl) return;

  const filter = $("#taskFilter").value;
  const sort = $("#taskSort").value;
  const query = $("#taskSearch").value.trim();

  listEl.innerHTML = "";
  const display = applyFilterAndSort(state.tasks, filter, sort, query);

  if (display.length === 0) {
    listEl.appendChild(create("div", "muted", "No tasks found. Create your first task on the left."));
    renderProgress();
    return;
  }

  display.forEach((task) => {
    const { isOverdue } = getDeadlineStatus(task.deadline);
    const item = create("div", "item");
    item.dataset.id = task.id;
    if (task.completed) item.classList.add("is-completed");
    if (!task.completed && isOverdue) item.classList.add("is-overdue");

    const top = create("div", "item__top");

    const left = create("div", "");
    const title = create("div", "item__title", task.title);
    const meta = create("div", "item__meta");

    const pTag = create("span", `tag tag--${task.priority}`, `${humanPriority(task.priority)} priority`);
    meta.appendChild(pTag);

    if (task.completed) meta.appendChild(create("span", "tag tag--done", "Completed"));

    if (task.deadline) {
      const dt = new Date(task.deadline);
      const when = dt.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
      meta.appendChild(create("span", "tag", when));
    } else {
      meta.appendChild(create("span", "tag", "No deadline"));
    }

    left.appendChild(title);
    if (task.description) left.appendChild(create("div", "muted", task.description));
    left.appendChild(meta);

    const actions = create("div", "actions");
    const toggleBtn = create("button", "chip-btn", task.completed ? "Mark active" : "Mark done");
    toggleBtn.type = "button";
    toggleBtn.dataset.action = "toggle";

    const editBtn = create("button", "chip-btn", "Edit");
    editBtn.type = "button";
    editBtn.dataset.action = "edit";

    const delBtn = create("button", "chip-btn chip-btn--danger", "Delete");
    delBtn.type = "button";
    delBtn.dataset.action = "delete";

    actions.appendChild(toggleBtn);
    actions.appendChild(editBtn);
    actions.appendChild(delBtn);

    top.appendChild(left);
    top.appendChild(actions);
    item.appendChild(top);

    listEl.appendChild(item);
  });

  renderProgress();
}

// ---------- Public stats (for dashboard) ----------
export function getTaskStats() {
  const total = state.tasks.length;
  const completed = state.tasks.filter((t) => t.completed).length;
  const dueSoon = state.tasks.filter((t) => !t.completed && withinHours(t.deadline, 24)).length;
  return { total, completed, dueSoon };
}

// ---------- Notifications ----------
export function checkDeadlineNotifications() {
  // We only notify for tasks due within 6 hours (and not completed)
  const dueSoon = state.tasks.filter((t) => !t.completed && withinHours(t.deadline, 6));
  if (dueSoon.length === 0) return;

  // Keep track of which task ids we already notified about in THIS TAB (sessionStorage example)
  const notifiedIds = loadSessionJSON(KEYS.SESSION_NOTIFIED_TASK_IDS, []);
  const notified = new Set(Array.isArray(notifiedIds) ? notifiedIds : []);

  const nowISO = new Date().toISOString();
  for (const t of dueSoon) {
    if (notified.has(t.id)) continue;
    notified.add(t.id);

    const when = new Date(t.deadline).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
    toast("Upcoming deadline", `${t.title} is due soon (${when}).`, { ttlMs: 9000 });
    pushNotification({
      id: `deadline_${t.id}`,
      title: "Upcoming deadline",
      message: `${t.title} is due soon (${when}).`,
      timeISO: nowISO,
    });
  }

  saveSessionJSON(KEYS.SESSION_NOTIFIED_TASK_IDS, Array.from(notified));
}

// ---------- Event wiring ----------
function bindForm() {
  const form = $("#taskForm");
  const titleEl = $("#taskTitle");
  const descEl = $("#taskDesc");
  const priorityEl = $("#taskPriority");
  const deadlineEl = $("#taskDeadline");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const valid = validateTaskForm({ titleEl, deadlineEl });
    if (!valid) return;

    const now = new Date().toISOString();
    const common = {
      title: valid.title,
      description: descEl.value.trim(),
      priority: priorityEl.value,
      deadline: valid.deadlineISO,
      updatedAt: now,
    };

    if (!state.editingId) {
      const task = {
        id: uuid(),
        completed: false,
        createdAt: now,
        ...common,
      };
      state.tasks.unshift(task);
      persist();
      toast("Task added", "Your task has been saved to localStorage.");
      resetForm();
    } else {
      const existing = state.tasks.find((t) => t.id === state.editingId);
      if (!existing) {
        resetForm();
        return;
      }
      const updated = { ...existing, ...common };
      upsertTask(updated);
      toast("Task updated", "Changes saved.");
      resetForm();
    }

    renderTaskList();
    state.onChange();
  });

  $("#taskCancelEdit").addEventListener("click", () => {
    resetForm();
  });
}

function bindToolbar() {
  $("#taskSearch").addEventListener("input", () => renderTaskList());
  $("#taskFilter").addEventListener("change", () => renderTaskList());
  $("#taskSort").addEventListener("change", () => renderTaskList());
}

function bindListActions() {
  const listEl = $("#taskList");
  listEl.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-action]");
    if (!btn) return;
    const item = e.target.closest(".item");
    if (!item) return;
    const id = item.dataset.id;
    const task = state.tasks.find((t) => t.id === id);
    if (!task) return;

    const action = btn.dataset.action;
    if (action === "toggle") {
      task.completed = !task.completed;
      task.updatedAt = new Date().toISOString();
      upsertTask(task);
      renderTaskList();
      toast("Task updated", task.completed ? "Marked as completed." : "Marked as active.");
      return;
    }

    if (action === "edit") {
      fillFormForEdit(task);
      toast("Edit mode", "Update the fields and click “Update Task”.", { ttlMs: 5000 });
      return;
    }

    if (action === "delete") {
      if (!confirmAction("Delete this task permanently?")) return;
      state.tasks = state.tasks.filter((t) => t.id !== id);
      persist();
      renderTaskList();
      state.onChange();
      toast("Task deleted", "Removed from localStorage.");
    }
  });
}

// ---------- Init ----------
export function initTasks({ onChange }) {
  state.onChange = onChange || (() => {});

  loadTasks();
  bindForm();
  bindToolbar();
  bindListActions();
  renderTaskList();
}

