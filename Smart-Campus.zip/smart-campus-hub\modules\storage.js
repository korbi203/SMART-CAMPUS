// storage.js
// A small, safe wrapper around localStorage + sessionStorage.
// - Uses JSON.stringify / JSON.parse
// - Provides defaults on missing/bad data
// - Keeps all storage keys in one place (easy to explain in a presentation)

export const KEYS = Object.freeze({
  TASKS: "sch_tasks_v1",
  NOTES: "sch_notes_v1",
  THEME: "sch_theme_v1",
  LAST_CITY: "sch_last_city_v1",
  LAST_WEATHER: "sch_last_weather_v1",
  AUTH_USER: "sch_auth_user_v1",

  // Session storage example (tab lifetime only)
  SESSION_NOTIFIED_TASK_IDS: "sch_session_notified_task_ids_v1",
  SESSION_LAST_VIEW: "sch_session_last_view_v1",
  SESSION_POMO_STATE: "sch_session_pomo_state_v1",
});

function safeParse(json, fallback) {
  try {
    return JSON.parse(json);
  } catch {
    return fallback;
  }
}

export function loadJSON(key, fallback) {
  const raw = localStorage.getItem(key);
  if (raw === null) return fallback;
  return safeParse(raw, fallback);
}

export function saveJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function remove(key) {
  localStorage.removeItem(key);
}

export function loadSessionJSON(key, fallback) {
  const raw = sessionStorage.getItem(key);
  if (raw === null) return fallback;
  return safeParse(raw, fallback);
}

export function saveSessionJSON(key, value) {
  sessionStorage.setItem(key, JSON.stringify(value));
}

export function setText(key, value) {
  localStorage.setItem(key, String(value));
}

export function getText(key, fallback = "") {
  const raw = localStorage.getItem(key);
  return raw === null ? fallback : raw;
}
