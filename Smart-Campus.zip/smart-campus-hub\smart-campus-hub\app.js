// Smart Campus Hub - App entry point (ES6 module)
// This file wires modules together and starts the application.

import { initUI, updateDashboard } from "./modules/ui.js";
import { initTasks, getTaskStats, checkDeadlineNotifications } from "./modules/tasks.js";
import { initNotes, getNotesCount } from "./modules/notes.js";
import { initWeather, getLastWeatherSummary } from "./modules/weather.js";

// Boot order:
// 1) UI (theme, nav, clock, toasts)
// 2) Feature modules (tasks, notes, weather)
// 3) Dashboard refresh + deadline notification checks

initUI({
  // Dashboard stats come from multiple modules, so we provide small callbacks.
  getStats: () => {
    const taskStats = getTaskStats();
    const notesCount = getNotesCount();
    const lastWeather = getLastWeatherSummary();
    return { taskStats, notesCount, lastWeather };
  },
});

initTasks({
  onChange: () => {
    updateDashboard();
    checkDeadlineNotifications();
  },
});

initNotes({
  onChange: () => {
    updateDashboard();
  },
});

initWeather({
  onChange: () => {
    updateDashboard();
  },
});

// Initial render
updateDashboard();
checkDeadlineNotifications();

// Periodic deadline checks (notification system)
// This demonstrates timers + dynamic UI updates.
setInterval(() => {
  checkDeadlineNotifications();
}, 60_000); // every minute

